<footer>
    <div class="footer container">
        <div class="col">
            <h4>"PIZZA" </h4>
            <p>
                35-500, Rzeszów<br />
                ul. Cicha 2<br />
                <i class="fas fa-phone-square"></i> 123 123 123<br />
                <i class="fas fa-envelope"></i> pizza@pizza.pl<br />
        </div>
        <div class="col">
            <p>
                Godziny otwarcia:
                <ul>
                    <li>Pon: 14:00 - 24:00</li>
                    <li>Wt: 14:00 - 24:00</li>
                    <li>Śr: 14:00 - 24:00</li>
                    <li>Czw: 14:00 - 24:00</li>
                    <li>Pt: 14:00 - 02:00</li>
                    <li>Sb: 14:00 - 02:00</li>
                    <li>Nd: 16:00 - 22:00</li>
                </ul>
            </p>
        </div>
        <div class="col">
            <p>
                All Rights Reserved &copy; by "PIZZA"
            </p>
        </div>
    </div>

</footer>