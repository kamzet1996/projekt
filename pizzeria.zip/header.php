<header>
    <img src='img/logo.png' alt='logo' class="logo" />
    <nav>
        <ul>
            <li><a href="index.php" class="nav_a">Strona główna</a></li>
            <li><a href="menu.php" class="nav_a">Zamów</a></li>
            <li><a href="opinie.php" class="nav_a">Opinie</a></li>
        </ul>
    </nav>
</header>